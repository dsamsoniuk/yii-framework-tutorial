<?php
namespace app\assets;

use yii\web\AssetBundle;

class AdminAsset extends AssetBundle
{
    public $sourcePath = '@app/themes/admin/assets';

    public $css = [
      //  'css/custom-css.css'
    ];

    public $js = [
        'https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js',
        '/js/custom.js',
    ];

    public $depends = [];

    public $publishOptions = [
        'forceCopy' => YII_DEBUG
    ];
}
