<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\{AuthToken, User};
use app\modules\log\models\LoginHistory;

class TokenLoginController extends Controller
{

    public $layout = '//main';

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex(int $userid, string $token)
    {
        if ($userid && $token) {
            $tokenModel = AuthToken::findOne([
                'user_id' => $userid,
                'token' => $token,
            ]);

            if (null !== $tokenModel) {
                $now = time();
                $tokenExpiration = $tokenModel->created_at + $tokenModel->ttl;

                if ($now < $tokenExpiration) {
                    $identity = User::findOne([
                        'id' => $userid,
                        'status' => 1,
                    ]);

                    if (null !== $identity) {
                        // Authorizing user and deleting token
                        if (Yii::$app->user->login($identity)) {
                            // LoginHistory::add(\Yii::$app->user->id, 1, $this->request->getUserIP());
                            $tokenModel->delete();

                            return $this->redirect( \yii\helpers\Url::to(['/admin']));
                        }
                    }
                } else {
                    // Token expired; deleting token
                    $tokenModel->delete();

                    Yii::$app->session->setFlash(
                        'error',
                        'Przepraszamy, ale token autoryzacyjny wygasł. Prosimy wygenerować nowy token.'
                    );
                }
            } else {
                // No token found
                Yii::$app->session->setFlash(
                    'error',
                    'Przepraszamy, ale link autoryzacyjny jest nieprawidłowy.'
                );
            }
        }

        return $this->redirect('/');
    }
}
