<?php

use yii\db\Migration;

/**
 * Class m240312_074333_new_tab_auth_token
 */
class m240312_074333_new_tab_auth_token extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('auth_token', [
            'id'                => $this->primaryKey(),
            'user_id'           => $this->integer()->notNull(),
            'created_by'        => $this->integer()->notNull(),
            'created_at'        => $this->integer()->null(),
            'token'             => $this->string()->null(),
            'ttl'               => $this->integer()->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('auth_token');
    }

}
