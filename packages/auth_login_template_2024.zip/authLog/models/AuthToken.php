<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auth_token".
 *
 * @property int $id
 * @property int $user_id Użytkownik
 * @property int $created_by Dodany przez
 * @property string $token
 * @property int $ttl Czas życia tokena w sekundach
 * @property int $created_at
 * @property int $updated_at
 */
class AuthToken extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'auth_token';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'created_by'], 'required'],
            [['user_id', 'created_by', 'ttl', 'created_at'], 'integer'],
            [['token'], 'string', 'max' => 255],
            [['ttl'], 'default', 'value' => 300],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'Użytkownik',
            'created_by' => 'Dodany przez',
            'token' => 'Token',
            'ttl' => 'Czas życia tokena',
            'created_at' => 'Dodano',
            'updated_at' => 'Edytowano',
        ];
    }

    public function beforeSave($insert)
    {
        $this->created_at = time();

        return parent::beforeSave($insert);
    }
}
