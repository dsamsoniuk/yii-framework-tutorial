<?php

namespace app\modules\admin\controllers;

use app\models\AuthToken;
use app\models\UserHasSystemToolsForm;
use Yii;
use app\models\User;
use app\models\UserSearch;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\Url;

/**
 * UserController implements the CRUD actions for User model.
 */
class UserController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['admin'],
                    ],
                ],
            ],
        ];
    }

    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel        = new UserSearch();
        $dataProvider       = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel'   => $searchModel,
            'dataProvider'  => $dataProvider,
        ]);
    }
    public function actionIndexAdmin()
    {
        $searchModel        = new UserSearch();
        $searchModel->role  = User::ROLE_ADMIN_FIRM;
        $dataProvider       = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index_admin', [
            'searchModel'   => $searchModel,
            'dataProvider'  => $dataProvider,
        ]);
    }

    /**
     * Displays a single User model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model          = new User();
        $userToolsForm  = new UserHasSystemToolsForm();
        if ($model->load(Yii::$app->request->post()) && $userToolsForm->load(Yii::$app->request->post()) && 
            $model->save() && $userToolsForm->setUser($model) && $userToolsForm->save()) {

            return $this->redirect(['index']);
        }

        return $this->render('create', [
            'model'         => $model,
            'userToolsForm' => $userToolsForm,
        ]);
    }
    public function actionCreateAdmin()
    {

        $model          = new User();
        $model->role    = User::ROLE_ADMIN_FIRM;
        $userToolsForm  = new UserHasSystemToolsForm();
        if ($model->load(Yii::$app->request->post()) && $userToolsForm->load(Yii::$app->request->post()) && 
            $model->save() && $userToolsForm->setUser($model) && $userToolsForm->save()) {
            return $this->redirect(['index-admin']);
        }

        return $this->render('create_admin', [
            'model'         => $model,
            'userToolsForm' => $userToolsForm,
        ]);
    }

    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model          = $this->findModel($id);
        $userToolsForm  = new UserHasSystemToolsForm($model);
        if ($model->load(Yii::$app->request->post()) && $userToolsForm->load(Yii::$app->request->post()) && 
            $model->save() && $userToolsForm->save()) {

            return $this->redirect(['index']);
        }

        return $this->render('update', [
            'model'         => $model,
            'userToolsForm' => $userToolsForm,
        ]);
    }

    public function actionUpdateAdmin($id)
    {

        $model          = $this->findModel($id);
        $userToolsForm  = new UserHasSystemToolsForm($model);
        if ($model->load(Yii::$app->request->post()) && $userToolsForm->load(Yii::$app->request->post()) && 
            $model->save() && $userToolsForm->save()) {

            return $this->redirect(['index-admin']);
        }

        return $this->render('update_admin', [
            'model'         => $model,
            'userToolsForm' => $userToolsForm,
        ]);
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
   /**
     * Generates token to authorize for specific user
     * @param integer $id
     * @return mixed
     */
    public function actionGenerateToken($id)
    {
        $response = [
            'status' => 0,
        ];

        $currentUser = Yii::$app->user->getIdentity();

        if ($currentUser->getRole() === 'admin') {
            if (($user = User::findOne($id)) !== null) {
                $tokenModel = AuthToken::findOne([
                    'user_id' => intval($id),
                ]);

                $token = bin2hex(openssl_random_pseudo_bytes(32));

                if (null !== $tokenModel) {
                    $tokenModel->created_by = intval($currentUser->id);
                    $tokenModel->token = $token;
                } else {
                    $tokenModel = new AuthToken;
                    $tokenModel->user_id = intval($id);
                    $tokenModel->created_by = intval($currentUser->id);
                    $tokenModel->token = $token;
                }

                $tokenModel->save();

                $response = [
                    'status' => 1,
                    'url' => Url::to(['/token-login/', 'userid' => intval($id), 'token' => $token], true),
                    'ttl' => $tokenModel->ttl,
                ];
            }
        }

        return $this->asJson($response);
    }
}
