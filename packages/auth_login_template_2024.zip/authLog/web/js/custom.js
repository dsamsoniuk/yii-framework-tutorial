const CustomAdmin = {
	select2ModelsCheckboxes: [],
    select2ModelsStaticWordInID: 'state_',
    init: function () {
	    bsCustomFileInput.init();

        $(document).on('click', '.btn-user-token', function (e) {
	    	e.preventDefault();
	    	const elem = $(this), data = elem.data();

	    	if (typeof data.url !== 'undefined' && typeof data.modal !== 'undefined') {
	    		$(data.modal).find('.modal-body').empty();

	    		$.ajax({
	    			cache: false,
	    			method: 'GET',
	    			url: data.url,
	    			dataType: 'json'
	    		})
	    		.done(function(response) {
	    			if (response.status === 1) {
	    				const modalBodyHtml = 'Aby zalogować się na konto użytkownika, skopiuj poniższy link i otwórz go w nowej przeglądarce.\
	    				<br>\
	    				Czas życia linku wynosi ' + response.ttl + ' sekund.\
                        <div class="input-group mt-3 mb-2">\
                            <input type="text" class="form-control" aria-describedby="button-addon2" value="' + response.url + '" readonly>\
                            <div class="input-group-append">\
                                <button class="btn btn-outline-primary btn-copy-link" type="button" id="button-addon2" title="Skopiuj link">\
                                    <i class="far fa-copy"></i>\
                                </button>\
                            </div>\
                        </div>';

	    				$(data.modal).find('.modal-body').html(modalBodyHtml);
	    				$(data.modal).modal('show');
	    			}
	    		});
	    	}
	    });

        $(document).on('click', '.input-group .btn-copy-link', function (e) {
            e.preventDefault();
            const btn = $(this), ig = btn.parents('.input-group:first'), field = ig.find('.form-control:input');
            const defaultTitle = 'Skopiuj link';
            const successtTitle = 'Skopiowano';
            const defaultIcon = '<i class="far fa-copy"></i>';
            const successIcon = '<i class="far fa-check-circle"></i>';

            if (field.length && field.val()) {
                try {
                    navigator.clipboard.writeText(field.val());

                    btn.addClass('btn-outline-success');
                    btn.attr('title', successtTitle);
                    btn.html(successIcon);
                } catch (e) {}
            }

            setTimeout(function () {
                btn.removeClass('btn-outline-success');
                btn.attr('title', defaultTitle);
                btn.html(defaultIcon);
            }, 3000);
        });

        if ($('select.select2').length) {
            $('select.select2').select2({
                language: 'pl',
                theme: 'bootstrap4',
                width: '100%',
            });
        }

        if ($('select.select2-ajax').length) {
            $('select.select2-ajax').select2({
                language: 'pl',
                theme: 'bootstrap4',
                width: '100%',
                minimumInputLength: 3,
                allowClear: true,
                ajax: {
                    delay: 500,
                    dataType: 'json',
                    type: 'GET',
                    data: function (params) {
                        const query = {
                            q: params.term || '',
                            page: params.page || 1
                        };

                        return query;
                    },
                }
            });
        }

        if ($('select#device-model-ids').length) {
            $.map($('#device-model-ids option'), function (option) {
                const selected = $(option).prop('selected');
                CustomAdmin.addItemSelect2MultiCheckbox(option.value, selected);
            });

            let select2ModelIds = $('select#device-model-ids').select2({
                language: 'pl',
                theme: 'bootstrap4',
                width: '100%',
                closeOnSelect: false,
                allowClear: true,
                templateResult: CustomAdmin.formatSelect2Result
            });

            select2ModelIds.on('select2:select', function (event) {
                $('#' + CustomAdmin.select2ModelsStaticWordInID + event.params.data.id).prop('checked', true);

                CustomAdmin.addItemSelect2MultiCheckbox(event.params.data.id, true);

                if (CustomAdmin.select2ModelsCheckboxes.filter(x => x.isChecked === false).length === 1) {
                    CustomAdmin.addItemSelect2MultiCheckbox(0, true);
                    $('#' + CustomAdmin.select2ModelsStaticWordInID + '0').prop('checked', true);
                }
            });

            select2ModelIds.on('select2:unselect', function (event) {
                $('#' + CustomAdmin.select2ModelsStaticWordInID + '0').prop('checked', false);
                CustomAdmin.addItemSelect2MultiCheckbox(0, false);

                $('#' + CustomAdmin.select2ModelsStaticWordInID + event.params.data.id).prop('checked', false);
                CustomAdmin.addItemSelect2MultiCheckbox(event.params.data.id, false);
            });

            $(document).on('change', '#checkbox_' + CustomAdmin.select2ModelsStaticWordInID + '0', function () {
                const firstOption = $('#checkbox_' + CustomAdmin.select2ModelsStaticWordInID + '0').is(':checked');

                CustomAdmin.isCheckedAllOption(firstOption);
            });

            $(document).on('change', '.select2-checkbox', function (event) {
                let selector = '#' + this.id;
                let currentId = this.id.replaceAll('checkbox_' + CustomAdmin.select2ModelsStaticWordInID, '');
                let isChecked = (typeof CustomAdmin.select2ModelsCheckboxes[currentId] !== 'undefined') ? CustomAdmin.select2ModelsCheckboxes[currentId].isChecked : false;

                $(selector).prop('checked', isChecked);
            });
        }
	},
    addItemSelect2MultiCheckbox: function (id, isChecked) {
        if (CustomAdmin.select2ModelsCheckboxes.length > 0) {
            let index = CustomAdmin.select2ModelsCheckboxes.findIndex(x => x.id == id);

            if (index > -1) {
                CustomAdmin.select2ModelsCheckboxes[index]['isChecked'] = isChecked;
            }
            else {
                CustomAdmin.select2ModelsCheckboxes.push({ "id": id, "isChecked": isChecked });
            }
        }
        else {
            CustomAdmin.select2ModelsCheckboxes.push({ "id": id, "isChecked": isChecked });
        }
    },
    isCheckedAllOption: function (state) {
        $.map($('#device-model-ids option'), function (option) {
            CustomAdmin.addItemSelect2MultiCheckbox(option.value, state);
        });

        $('#device-model-ids > option').not(':first').prop('selected', state);
        $('#device-model-ids').trigger('change');

        $('.select2-results__option').not(':first').attr('aria-selected', state);

        console.log(CustomAdmin.select2ModelsStaticWordInID);

        $('input[id^="checkbox_' + CustomAdmin.select2ModelsStaticWordInID + '"]').prop('checked', state);
    },
    formatSelect2Result: function (state) {
        if (CustomAdmin.select2ModelsCheckboxes.length > 0) {
            var stateId = CustomAdmin.select2ModelsStaticWordInID + state.id;
            let index = CustomAdmin.select2ModelsCheckboxes.findIndex(x => x.id == state.id);

            if (index > -1) {
                var checkbox = $('<div class="custom-control custom-checkbox"><input class="custom-control-input select2-checkbox" id="checkbox_' + stateId + '" type="checkbox" ' + (CustomAdmin.select2ModelsCheckboxes[index]['isChecked'] ? 'checked' : '') +
                    '><label for="checkbox_' + stateId + '" class="custom-control-label w-100">' + state.text + '</label></div>', { id: stateId });
                return checkbox;
            }
        }
    }
};

$(function() {
	CustomAdmin.init();
});
